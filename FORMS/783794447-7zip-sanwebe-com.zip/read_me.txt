@Package		: 10 CSS form styles
@Downloaded from	: http://www.sanwebe.com
@License 		: (The MIT License) http://opensource.org/licenses/MIT